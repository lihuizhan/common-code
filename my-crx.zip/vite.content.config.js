// vite.content.config.js
import { defineConfig } from 'vite';
import { resolve } from 'path';
import vue from '@vitejs/plugin-vue';
import AutoImport from 'unplugin-auto-import/vite';
import Components from 'unplugin-vue-components/vite';
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers';
import replace from '@rollup/plugin-replace';

export default defineConfig({
  build: {
    outDir: 'dist',
    emptyOutDir: false, // ← 关键！不删除 dist/
    minify: false,
    lib: {
      entry: resolve(__dirname, 'src/content/main.js'),
      name: 'ContentScript',
      formats: ['iife'], // ← 关键！生成自执行函数
      fileName: () => 'content-bundle.js'
    },
    rollupOptions: {
      output: {
        entryFileNames: 'content-bundle.js',
        // 禁止生成 chunk，所有代码内联
        inlineDynamicImports: true
      }
    }
  },
  plugins: [
    replace({
      preventAssignment: true,
      'process.env.NODE_ENV': JSON.stringify('production')
    }),
    vue(),
    AutoImport({ resolvers: [ElementPlusResolver()] }),
    Components({ resolvers: [ElementPlusResolver({ importStyle: 'css' })] })
  ]
});
