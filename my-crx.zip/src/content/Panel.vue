<!-- src/content/Panel.vue -->
<template>
  <div class="panel">
    <h3>🔍 高亮工具</h3>
    <el-input v-model="keyword" placeholder="输入关键词" @keyup.enter="doHighlight" />
    <div style="margin-top: 10px;">
      <el-button type="primary" @click="doHighlight">高亮</el-button>
      <el-button @click="clear">清除</el-button>
      <el-button @click="close">关闭</el-button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { highlightKeyword, clearHighlights } from './highlight.js';

const keyword = ref('');

const doHighlight = () => {
  highlightKeyword(keyword.value);
};

const clear = () => {
  clearHighlights();
};

const close = () => {
  document.dispatchEvent(new CustomEvent('close-panel'));
};
</script>

<style scoped>
.panel {
  padding: 16px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  max-width: 280px;
}
</style>