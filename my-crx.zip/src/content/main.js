// src/content/main.js
import { createApp } from 'vue';
import Panel from './Panel.vue';

// 1. 创建容器
const container = document.createElement('div');
container.id = '__my_extension_container__';
container.style.cssText = `
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 2147483647;
  font-size: 14px;
`;
document.body.appendChild(container);

// 2. （可选）使用 Shadow DOM 隔离样式
const shadow = container.attachShadow({ mode: 'open' });
const style = document.createElement('style');
style.textContent = `* { margin:0; padding:0; box-sizing:border-box; }`;
shadow.appendChild(style);

const appRoot = document.createElement('div');
shadow.appendChild(appRoot);

// 如果不用 Shadow DOM，直接挂载到 container
// const appRoot = container;

// 3. 创建并挂载 Vue App
const app = createApp(Panel);
app.mount(appRoot);

// 4. 监听关闭事件
document.addEventListener('close-panel', () => {
  app.unmount();
  container.remove();
});

console.log('[Content] Vue panel injected.');