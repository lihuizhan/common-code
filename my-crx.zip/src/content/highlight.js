// src/content/highlight.js

const HIGHLIGHT_CLASS = '__my_ext_highlight__';
const HIGHLIGHT_STYLE_ID = '__my_ext_highlight_style__';

// 注入高亮样式（只注入一次）
function injectHighlightStyle() {
  if (document.getElementById(HIGHLIGHT_STYLE_ID)) return;

  const style = document.createElement('style');
  style.id = HIGHLIGHT_STYLE_ID;
  style.textContent = `
    .${HIGHLIGHT_CLASS} {
      background-color: #ffeb3b !important;
      color: #000 !important;
      padding: 0 2px !important;
      border-radius: 2px !important;
      font-weight: bold !important;
      pointer-events: none !important;
    }
  `;
  document.head.appendChild(style);
}

// 清除所有高亮
export function clearHighlights() {
  document.querySelectorAll(`.${HIGHLIGHT_CLASS}`).forEach(el => {
    const parent = el.parentNode;
    if (parent) {
      while (el.firstChild) {
        parent.insertBefore(el.firstChild, el);
      }
      parent.removeChild(el);
    }
  });
}

// 高亮关键词（递归遍历文本节点）
export function highlightKeyword(keyword) {
  if (!keyword.trim()) return;

  clearHighlights();
  injectHighlightStyle();

  const body = document.body;
  if (!body) return;

  const walker = document.createTreeWalker(
    body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        // 跳过 script/style 等标签内的文本
        const parent = node.parentElement;
        if (!parent || ['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(parent.tagName)) {
          return NodeFilter.FILTER_REJECT;
        }
        // 只处理包含关键词的文本
        if (node.nodeValue && node.nodeValue.toLowerCase().includes(keyword.toLowerCase())) {
          return NodeFilter.FILTER_ACCEPT;
        }
        return NodeFilter.FILTER_REJECT;
      }
    }
  );

  const textNodes = [];
  let node;
  while ((node = walker.nextNode())) {
    textNodes.push(node);
  }

  // 从后往前处理，避免 DOM 修改影响索引
  for (let i = textNodes.length - 1; i >= 0; i--) {
    const textNode = textNodes[i];
    const text = textNode.nodeValue;
    const parts = text.split(new RegExp(`(${keyword})`, 'gi'));
    if (parts.length <= 1) continue;

    const fragment = document.createDocumentFragment();
    parts.forEach((part, idx) => {
      if (idx % 2 === 1) {
        // 关键词部分
        const mark = document.createElement('span');
        mark.className = HIGHLIGHT_CLASS;
        mark.textContent = part;
        fragment.appendChild(mark);
      } else if (part) {
        // 普通文本
        fragment.appendChild(document.createTextNode(part));
      }
    });

    textNode.parentNode.replaceChild(fragment, textNode);
  }
}