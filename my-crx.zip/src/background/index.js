console.log('[Background] Loaded.');
chrome.runtime.onInstalled.addListener(() => console.log('Installed'));