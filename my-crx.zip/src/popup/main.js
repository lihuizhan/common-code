// src/popup/main.js
document.addEventListener('DOMContentLoaded', () => {
  const statusEl = document.getElementById('status');
  const toggleBtn = document.getElementById('toggle');

  // 示例：从 storage 读取状态
  chrome.storage.local.get(['enabled'], (result) => {
    const enabled = result.enabled ?? true;
    statusEl.textContent = enabled ? '✅ Enabled' : '❌ Disabled';
    toggleBtn.textContent = enabled ? 'Disable' : 'Enable';
  });

  toggleBtn.addEventListener('click', () => {
    chrome.storage.local.get(['enabled'], (result) => {
      const newEnabled = !(result.enabled ?? true);
      chrome.storage.local.set({ enabled: newEnabled }, () => {
        // 通知当前 tab 的 content script（可选）
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs && tabs.length > 0) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'toggle', enabled: newEnabled });
          }
        });
        location.reload(); // 简单刷新 popup
      });
    });
  });
});