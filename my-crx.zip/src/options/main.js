// src/options/main.js
document.addEventListener('DOMContentLoaded', () => {
  const autoRunCheckbox = document.getElementById('autoRun');
  const saveBtn = document.getElementById('save');
  const messageEl = document.getElementById('message');

  // 加载已保存设置
  chrome.storage.sync.get(['autoRun'], (result) => {
    autoRunCheckbox.checked = result.autoRun ?? true;
  });

  saveBtn.addEventListener('click', () => {
    const settings = {
      autoRun: autoRunCheckbox.checked
    };
    chrome.storage.sync.set(settings, () => {
      messageEl.textContent = '✅ Settings saved!';
      setTimeout(() => messageEl.textContent = '', 2000);
    });
  });
});