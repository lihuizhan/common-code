function createImage({
  width = 200,
  height = 200,
  bgColor = '#ffffff',
  textColor = '#000000',
  text = 'Text',
  isCircle = false
}) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  // 清空
  ctx.clearRect(0, 0, width, height);

  if (isCircle) {
    const radius = Math.min(width, height) / 2;
    const centerX = width / 2;
    const centerY = height / 2;

    // 创建圆形裁剪区域
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2, false);
    ctx.closePath();
    ctx.clip();

    // 填充背景（裁剪后只在圆内绘制）
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, width, height);
  } else {
    // 矩形背景
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, width, height);
  }

  // 绘制文字
  ctx.fillStyle = textColor;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // const fontSize = Math.max(12, Math.min(width, height) / 4); // 根据画布大小调整字体
  // ctx.font = `bold ${fontSize}px Arial, sans-serif`;
  let fontSize;
  if (width > 100) {
    fontSize = Math.min(width, height) / 2;
  } else if (width > 50) {
    fontSize = Math.min(width, height) / 2.5;
  } else if (width > 20) {
    fontSize = Math.min(width, height) / 2;
  } else if (width > 10) {
    fontSize = 12;
  } else {
    fontSize = Math.max(12, Math.min(width, height) / 4);
  }
  ctx.font = `bold ${fontSize}px Arial, sans-serif`;

  ctx.fillText(text, width / 2, height / 2);

  return canvas;
}

for (const size of [16, 48, 128]) {
  const canvas = createImage({
    width: size,
    height: size,
    // bgColor: '#e91e63',
    bgColor: '#00aeec',
    textColor: '#ffffff',
    text: 'L',
    isCircle: true
  });

  document.body.appendChild(canvas);

  // 下载图片
  const link = document.createElement('a');
  link.download = `icon${size}.png`;
  link.href = canvas.toDataURL('image/png');
  link.click();
}