// vite.config.js
import { defineConfig } from 'vite';
import { resolve } from 'path';
import vue from '@vitejs/plugin-vue';
import AutoImport from 'unplugin-auto-import/vite';
import Components from 'unplugin-vue-components/vite';
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers';
import copy from 'rollup-plugin-copy';

export default defineConfig({
  build: {
    outDir: 'dist',
    minify: false,
    rollupOptions: {
      input: {
        'content-bundle': resolve(__dirname, 'src/content/main.js'),
        'background-bundle': resolve(__dirname, 'src/background/index.js'),
        popup: resolve(__dirname, 'src/popup/index.html'),
        options: resolve(__dirname, 'src/options/index.html'),
      },
      output: {
        format: 'es',
        entryFileNames: `[name].js`,
        chunkFileNames: `[name].js`,
        assetFileNames: `[name].[ext]`,
      }
    }
  },
  plugins: [
    vue(), // 启用 Vue SFC 支持
    AutoImport({
      resolvers: [ElementPlusResolver()],
    }),
    Components({
      resolvers: [ElementPlusResolver({ importStyle: 'css' })],
    }),
    copy({
      targets: [
        { src: 'public/manifest.json', dest: 'dist' },
        { src: 'public/icons/*', dest: 'dist/icons' }
      ],
      hook: 'writeBundle'
    })
  ]
});
