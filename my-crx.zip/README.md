




    // "dev": "vite build --watch",
    // "build": "vite build"


    你整理一份 完整可运行的 ZIP 项目 吗？包含所有配置和文件，开箱即用

    emptyOutDir: false, // ← 关键！不删除 dist/




background、content script、 popup、devtools-js 之间通信的最佳实践
避免出现以下错误
Uncaught (in promise) Error: Could not establish connection. Receiving end does not exist.
The message port closed before a response was received