// vite.app.config.js
import { defineConfig } from 'vite';
import { resolve } from 'path';
import vue from '@vitejs/plugin-vue';
import AutoImport from 'unplugin-auto-import/vite';
import Components from 'unplugin-vue-components/vite';
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers';
import copy from 'rollup-plugin-copy';
import replace from '@rollup/plugin-replace';

export default defineConfig({
  build: {
    outDir: 'dist',
    emptyOutDir: false, // ← 关键！不删除 dist/
    minify: false,
    rollupOptions: {
      input: {
        'background-bundle': resolve(__dirname, 'src/background/index.js'),
        popup: resolve(__dirname, 'src/popup/index.html'),
        options: resolve(__dirname, 'src/options/index.html'),
      },
      output: {
        format: 'es', // background 必须是模块
        entryFileNames: `[name].js`,
        chunkFileNames: `[name].js`,
        assetFileNames: `[name].[ext]`,
      }
    }
  },
  plugins: [
    replace({
      preventAssignment: true,
      'process.env.NODE_ENV': JSON.stringify('production')
    }),
    vue(),
    AutoImport({ resolvers: [ElementPlusResolver()] }),
    Components({ resolvers: [ElementPlusResolver({ importStyle: 'css' })] }),
    copy({
      targets: [
        { src: 'public/manifest.json', dest: 'dist' },
        { src: 'public/icons/*', dest: 'dist/icons' }
      ],
      hook: 'writeBundle'
    })
  ]
});
