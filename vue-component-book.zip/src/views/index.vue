<template>
    <div>
        《Vue.js组件精讲》示例
    </div>
</template>
<script>
    export default {

    }
</script>