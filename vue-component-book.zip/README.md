
![](https://file.iviewui.com/vue-component-book.png)

购买地址：[https://juejin.im/book/5bc844166fb9a05cd676ebca](https://juejin.im/book/5bc844166fb9a05cd676ebca)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```
