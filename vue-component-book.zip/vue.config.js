module.exports = {
    runtimeCompiler: true
};