/**
 * 身份证校验
 * @param {number} idNum 身份证号码
 * @param {yange}   是否启用严格模式，默认为false
 * 
 * 
 */
function verifyIdcard(idNum, yange = false) {

  console.log(idNum)
  let format = /^(([1][1-5])|([2][1-3])|([3][1-7])|([4][1-6])|([5][0-4])|([6][1-5])|([7][1])|([8][1-2]))\d{4}(([1][9]\d{2})|([2]\d{3}))(([0][1-9])|([1][0-2]))(([0][1-9])|([1-2][0-9])|([3][0-1]))\d{3}[0-9xX]$/;
  if (!format.test(idNum)) {
    console.error(`身份证号码有误`)
    return false
  }
  if (yange) {
    //身份证城市
    let aCity = {
      11: "北京",
      12: "天津",
      13: "河北",
      14: "山西",
      15: "内蒙古",
      21: "辽宁",
      22: "吉林",
      23: "黑龙江",
      31: "上海",
      32: "江苏",
      33: "浙江",
      34: "安徽",
      35: "福建",
      36: "江西",
      37: "山东",
      41: "河南",
      42: "湖北",
      43: "湖南",
      44: "广东",
      45: "广西",
      46: "海南",
      50: "重庆",
      51: "四川",
      52: "贵州",
      53: "云南",
      54: "西藏",
      61: "陕西",
      62: "甘肃",
      63: "青海",
      64: "宁夏",
      65: "新疆",
      71: "台湾",
      81: "香港",
      82: "澳门",
      91: "国外"
    };
    console.log(aCity[parseInt(idNum.substr(0, 2))])
    if (!aCity[parseInt(idNum.toString().substr(0, 2))]) {
      console.error("你的身份证地区非法");
      return false;
    }

    var sum = 0,
      weights = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2],
      codes = "10X98765432";
    for (var i = 0; i < idNum.length - 1; i++) {
      sum += idNum[i] * weights[i];
    }
    var last = codes[sum % 11]; // 计算出来的最后一位身份证号码
    if (idNum[idNum.length - 1] != last) {
      console.error("你输入的身份证号非法");
      return false;
    }
  }
  let y = Number(idNum.substr(6, 4)) // 身份证年
  let m = Number(idNum.substr(10, 2)) // 身份证月
  let d = Number(idNum.substr(12, 2)) // 身份证日

  // 在验证一下闰年闰月是否正确
  let isLeapYM = time_isLeapYM(y, m)
  if (isLeapYM.month == true) {
    if (d > 29) {
      console.error(`${y}年，2月没有${d}`)
    }
    return false
  }
  if (isLeapYM.year == true || m == 2) {
    if (d > 28) {
      console.error(`${y}年，2月没有${d}`)
    }
    return false
  }

  return true
};

//判断是否是闰年/闰月
function time_isLeapYM(y, m) {
  let obj = {
    year: false, //是否为闰年
    month: false, //是否为闰年闰月
  }
  if (isLeapYear(y)) {
    obj.year = true;
    if (m == 2) {
      obj.month = true
    }
  }
  return obj
};

// 检查传入的年份是否是闰年
function isLeapYear(year) {
  if ((year / 4 == Math.floor(year / 4) && year / 100 != Math.floor(year / 100)) || (year / 400 == Math.floor(year / 400) && year / 3200 != Math.floor(year / 3200)) || year / 172800 == Math.floor(year / 172800)) {
    return true
  }
  return false
}

console.log(verifyIdcard('332522198705040011'));