# Vue.js 组件精讲

- [x] 开篇：Vue.js 的精髓——组件
- [x] 基础：Vue.js 组件的三个 API：prop、event、slot
- [x] 组件的通信 1：provide / inject
- [x] 组件的通信 2：派发与广播——自行实现 dispatch 和 broadcast 方法
- [x] 实战 1：具有数据校验功能的表单组件——Form
- [ ] 组件的通信 3：找到任意组件实例——findComponents 系列方法
- [ ] 实战 2：组合多选框组件——CheckboxGroup &amp; Checkbox
- [ ] Vue 的构造器——extend 与手动挂载——$mount
- [ ] 实战 3：动态渲染 .vue 文件的组件—— Display
- [ ] 实战 4：全局提示组件——$Alert
- [ ] 更灵活的组件：Render 函数与 Functional Render
- [ ] 实战 5：可用 Render 自定义列的表格组件——Table
- [ ] 实战 6：可用 slot-scope 自定义列的表格组件——Table
- [ ] 递归组件与动态组件
- [ ] 实战 7：树形控件——Tree
- [ ] 拓展：Vue.js 容易忽略的 API 详解
- [ ] 拓展：Vue.js 面试、常见问题答疑
- [ ] 拓展：如何做好一个开源项目（上篇）
- [ ] 拓展：如何做好一个开源项目（下篇）
- [ ] 写在最后


mixins
$emit